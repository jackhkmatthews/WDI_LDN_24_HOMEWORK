console.log('js loaded');

var audio = new Audio('pig.mp3');
audio.play();
